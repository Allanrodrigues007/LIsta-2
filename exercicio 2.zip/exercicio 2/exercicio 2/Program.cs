﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio_2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double numero1;
            double numero2;

            Console.WriteLine("digite o primeiro valor");
            numero1 = double.Parse(Console.ReadLine());

            Console.WriteLine("digite o segundo valor");
            numero2 = double.Parse(Console.ReadLine());


            if (numero1 == numero2)
            {

                Console.WriteLine("os valores são identicos");
            }
            else
            {
                if (numero2 < numero1)
                {
                    Console.WriteLine("primeiro valor é maior");
                }
                else
                {
                    Console.WriteLine("o segundo valor é maior");
                }
            }
        }
    }
}

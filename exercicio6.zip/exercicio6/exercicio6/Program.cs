﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio6
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double numero1;
            double numero2;
            double resultado;

            Console.WriteLine("digite seu peso amigão");
            numero1 = double.Parse(Console.ReadLine());

            Console.WriteLine("digite sua altura meu amigão");
            numero2 = double.Parse(Console.ReadLine());

            resultado = numero1 / (numero2*numero2);


            if (resultado < 20)
            {

                Console.WriteLine("abaixo do peso");
            }
            else
            {
                if (20 <= resultado < 25)
                {
                 
                   Console.WriteLine("peso ideal");
                }
                else 
                {
                 if ( resultado >=25)

                        Console.WriteLine("Acima do peso");
                }

            }
        }
    }
}
    


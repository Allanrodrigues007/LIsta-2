﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio3
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double numero1;
            double numero2;
            double area;

            Console.WriteLine("digite o valor da base");
            numero1 = double.Parse(Console.ReadLine());

            Console.WriteLine("digite o valor da altura");
            numero2 = double.Parse(Console.ReadLine());

            area = (numero1 * numero2 / 2);


            if (area > 100)
            {

                Console.WriteLine("o terreno é grande");
            }
            else
            {
                Console.WriteLine("terreno pequeno");


            }
        }
    }
}
